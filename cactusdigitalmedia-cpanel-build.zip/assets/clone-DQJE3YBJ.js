import{b as r}from"./_baseUniq-D3RCzwIc.js";var e=4;function a(o){return r(o,e)}export{a as c};
