import{b as r}from"./_baseUniq-Ct4K3GQd.js";var e=4;function a(o){return r(o,e)}export{a as c};
